Cognigy-CoCo Integration
